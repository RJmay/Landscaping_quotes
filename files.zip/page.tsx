"use client";
// src/app/page.tsx
// Main quoting page. Orchestrates the full flow:
//   Address → Job selection → Property sizes → Modifiers → Quote

import { useEffect, useState, useCallback } from "react";
import AddressAutocomplete from "@/components/AddressAutocomplete";
import JobSelector from "@/components/JobSelector";
import PropertyInputs from "@/components/PropertyInputs";
import QuoteCard from "@/components/QuoteCard";
import QuoteLoading from "@/components/QuoteLoading";
import { fetchJobs, submitQuote, Job, QuoteResponse } from "@/lib/api";

// ─── State types ──────────────────────────────────────────────────────────────

interface FormState {
  // Address
  addressDisplay: string;
  addressParsed: { full: string; suburb: string; state: string; postcode: string } | null;

  // Jobs
  selectedJobIds: string[];

  // Property sizes (Step 4 will auto-fill these from Maps)
  lawn_sqm: number;
  driveway_sqm: number;
  roof_sqm: number;
  garden_sqm: number;

  // Modifiers
  terrain: "flat" | "sloped" | "unknown";
  travel_zone: "A" | "B" | "C";
  access_notes: string;
}

const INITIAL_FORM: FormState = {
  addressDisplay: "",
  addressParsed: null,
  selectedJobIds: [],
  lawn_sqm: 250,
  driveway_sqm: 45,
  roof_sqm: 155,
  garden_sqm: 35,
  terrain: "flat",
  travel_zone: "A",
  access_notes: "",
};

type Stage = "form" | "loading" | "result";

// ─── Component ────────────────────────────────────────────────────────────────

export default function HomePage() {
  const [form, setForm] = useState<FormState>(INITIAL_FORM);
  const [jobs, setJobs] = useState<Job[]>([]);
  const [jobsError, setJobsError] = useState<string | null>(null);
  const [stage, setStage] = useState<Stage>("form");
  const [quote, setQuote] = useState<QuoteResponse | null>(null);
  const [errors, setErrors] = useState<Record<string, string>>({});
  const [apiError, setApiError] = useState<string | null>(null);
  const [showModifiers, setShowModifiers] = useState(false);

  // Load job types on mount
  useEffect(() => {
    fetchJobs()
      .then(setJobs)
      .catch(() => setJobsError("Could not load services. Is the backend running?"));
  }, []);

  const updateForm = useCallback((key: keyof FormState, value: unknown) => {
    setForm((prev) => ({ ...prev, [key]: value }));
    setErrors((prev) => { const next = { ...prev }; delete next[key]; return next; });
  }, []);

  const validate = (): boolean => {
    const e: Record<string, string> = {};
    if (!form.addressDisplay.trim()) e.address = "Please enter your property address";
    if (form.selectedJobIds.length === 0) e.jobs = "Please select at least one service";
    setErrors(e);
    return Object.keys(e).length === 0;
  };

  const handleSubmit = async () => {
    if (!validate()) return;
    setApiError(null);
    setStage("loading");

    // Build suburb/state from parsed address or fallback to manual guess
    const suburb = form.addressParsed?.suburb || extractSuburb(form.addressDisplay);
    const state = form.addressParsed?.state || "QLD";

    // Condition context: a human-readable description for Claude
    // Step 5 will replace this with weather + satellite data
    const condition_context = `Standard suburban property in ${suburb}, ${state}. No automated condition data available yet (Step 5 pending).`;

    try {
      const result = await submitQuote({
        address: form.addressDisplay,
        suburb,
        state,
        job_ids: form.selectedJobIds,
        lawn_sqm: form.lawn_sqm,
        driveway_sqm: form.driveway_sqm,
        roof_sqm: form.roof_sqm,
        garden_sqm: form.garden_sqm,
        condition_score: 0.4, // Step 5 will compute this from weather/suburb data
        condition_context,
        travel_zone: form.travel_zone,
        terrain: form.terrain,
        access_notes: form.access_notes || undefined,
      });
      setQuote(result);
      setStage("result");
    } catch (err: unknown) {
      setApiError(err instanceof Error ? err.message : "Something went wrong. Please try again.");
      setStage("form");
    }
  };

  const handleReset = () => {
    setForm(INITIAL_FORM);
    setQuote(null);
    setApiError(null);
    setErrors({});
    setStage("form");
  };

  // ── Render ──────────────────────────────────────────────────────────────────

  return (
    <div
      style={{
        minHeight: "100vh",
        background: "var(--mist)",
        padding: "0 0 80px",
      }}
    >
      {/* Hero header */}
      <header
        style={{
          background: "var(--bark)",
          padding: "40px 24px 48px",
          textAlign: "center",
          position: "relative",
          overflow: "hidden",
        }}
      >
        {/* Decorative texture */}
        <div
          style={{
            position: "absolute", inset: 0,
            backgroundImage: `radial-gradient(circle at 20% 50%, rgba(90,154,74,0.15) 0%, transparent 60%),
                              radial-gradient(circle at 80% 20%, rgba(196,151,90,0.1) 0%, transparent 50%)`,
            pointerEvents: "none",
          }}
        />

        <div style={{ position: "relative" }}>
          <p style={{ fontSize: 13, color: "var(--sage)", fontWeight: 500, letterSpacing: "0.1em", textTransform: "uppercase", marginBottom: 12 }}>
            🌿 Instant pricing
          </p>
          <h1
            style={{
              fontFamily: "var(--font-display)",
              fontSize: "clamp(28px, 6vw, 48px)",
              color: "#f5f0e8",
              marginBottom: 12,
              fontStyle: "italic",
            }}
          >
            Get your landscaping quote
          </h1>
          <p style={{ fontSize: 15, color: "rgba(240,237,230,0.7)", maxWidth: 440, margin: "0 auto" }}>
            Enter your address, pick your services, and get an accurate price estimate in seconds.
          </p>
        </div>
      </header>

      {/* Main content */}
      <main
        style={{
          maxWidth: 640,
          margin: "0 auto",
          padding: "0 16px",
          marginTop: -20,
        }}
      >
        {/* Backend error */}
        {jobsError && (
          <div
            style={{
              background: "#fff0f0",
              border: "1px solid #f5c6c6",
              borderRadius: "var(--radius-md)",
              padding: "14px 18px",
              marginBottom: 16,
              fontSize: 14,
              color: "#8b2020",
            }}
          >
            ⚠ {jobsError}
          </div>
        )}

        {/* ── FORM ───────────────────────────────────────────────────── */}
        {stage === "form" && (
          <div
            className="animate-fade-up"
            style={{
              background: "var(--parchment)",
              borderRadius: "var(--radius-lg)",
              padding: "28px 24px",
              boxShadow: "var(--shadow-float)",
              border: "1px solid var(--fog)",
              display: "flex",
              flexDirection: "column",
              gap: 28,
            }}
          >
            {/* Address */}
            <section>
              <SectionLabel number={1} title="Your property address" />
              <AddressAutocomplete
                value={form.addressDisplay}
                onChange={(display, parsed) => {
                  updateForm("addressDisplay", display);
                  updateForm("addressParsed", parsed);
                }}
                error={errors.address}
                disabled={stage !== "form"}
              />
            </section>

            {/* Services */}
            <section>
              <SectionLabel number={2} title="Services needed" />
              {jobs.length === 0 && !jobsError ? (
                <div style={{ display: "flex", gap: 8, alignItems: "center", padding: "16px 0" }}>
                  <div style={{ width: 16, height: 16, borderRadius: "50%", border: "2px solid var(--sage)", borderTopColor: "var(--meadow)", animation: "spin 0.7s linear infinite" }} />
                  <span style={{ fontSize: 13, color: "var(--clay)" }}>Loading services...</span>
                </div>
              ) : (
                <JobSelector
                  jobs={jobs}
                  selected={form.selectedJobIds}
                  onChange={(ids) => updateForm("selectedJobIds", ids)}
                  error={errors.jobs}
                />
              )}
            </section>

            {/* Property size */}
            <section>
              <SectionLabel number={3} title="Property sizes" subtitle="Step 4 will detect these automatically from satellite imagery" />
              <PropertyInputs
                values={{
                  lawn_sqm: form.lawn_sqm,
                  driveway_sqm: form.driveway_sqm,
                  roof_sqm: form.roof_sqm,
                  garden_sqm: form.garden_sqm,
                }}
                onChange={(key, val) => updateForm(key, val)}
              />
            </section>

            {/* Optional modifiers */}
            <section>
              <button
                type="button"
                onClick={() => setShowModifiers(!showModifiers)}
                style={{
                  background: "none",
                  border: "none",
                  color: "var(--clay)",
                  fontSize: 13,
                  fontFamily: "var(--font-body)",
                  cursor: "pointer",
                  display: "flex",
                  alignItems: "center",
                  gap: 6,
                  padding: 0,
                }}
              >
                <span style={{ transform: showModifiers ? "rotate(90deg)" : "none", transition: "transform 0.2s", display: "inline-block" }}>▶</span>
                Additional details (optional)
              </button>

              {showModifiers && (
                <div
                  className="animate-fade-up"
                  style={{ marginTop: 14, display: "flex", flexDirection: "column", gap: 14 }}
                >
                  {/* Terrain */}
                  <div>
                    <label style={{ fontSize: 12, fontWeight: 500, color: "var(--bark)", display: "block", marginBottom: 6 }}>
                      Terrain
                    </label>
                    <div style={{ display: "flex", gap: 8 }}>
                      {(["flat", "sloped", "unknown"] as const).map((t) => (
                        <button
                          key={t}
                          type="button"
                          onClick={() => updateForm("terrain", t)}
                          style={{
                            padding: "8px 16px",
                            fontSize: 13,
                            fontFamily: "var(--font-body)",
                            fontWeight: 500,
                            background: form.terrain === t ? "var(--meadow)" : "var(--parchment)",
                            border: `1.5px solid ${form.terrain === t ? "var(--meadow)" : "var(--fog)"}`,
                            borderRadius: "var(--radius-sm)",
                            color: form.terrain === t ? "#fff" : "var(--bark)",
                            cursor: "pointer",
                            transition: "all 0.15s",
                            textTransform: "capitalize",
                          }}
                        >
                          {t}
                        </button>
                      ))}
                    </div>
                  </div>

                  {/* Travel zone */}
                  <div>
                    <label style={{ fontSize: 12, fontWeight: 500, color: "var(--bark)", display: "block", marginBottom: 6 }}>
                      Distance from depot
                    </label>
                    <div style={{ display: "flex", gap: 8 }}>
                      {[
                        { zone: "A", label: "Within 10km" },
                        { zone: "B", label: "10–25km" },
                        { zone: "C", label: "25km+" },
                      ].map(({ zone, label }) => (
                        <button
                          key={zone}
                          type="button"
                          onClick={() => updateForm("travel_zone", zone as "A" | "B" | "C")}
                          style={{
                            flex: 1,
                            padding: "8px 8px",
                            fontSize: 12,
                            fontFamily: "var(--font-body)",
                            fontWeight: 500,
                            background: form.travel_zone === zone ? "var(--meadow)" : "var(--parchment)",
                            border: `1.5px solid ${form.travel_zone === zone ? "var(--meadow)" : "var(--fog)"}`,
                            borderRadius: "var(--radius-sm)",
                            color: form.travel_zone === zone ? "#fff" : "var(--bark)",
                            cursor: "pointer",
                            transition: "all 0.15s",
                          }}
                        >
                          {label}
                        </button>
                      ))}
                    </div>
                  </div>

                  {/* Access notes */}
                  <div>
                    <label style={{ fontSize: 12, fontWeight: 500, color: "var(--bark)", display: "block", marginBottom: 6 }}>
                      Access notes
                    </label>
                    <textarea
                      value={form.access_notes}
                      onChange={(e) => updateForm("access_notes", e.target.value)}
                      placeholder="e.g. narrow side gate, dogs on property, steep driveway..."
                      rows={2}
                      style={{
                        width: "100%",
                        padding: "10px 12px",
                        fontSize: 14,
                        fontFamily: "var(--font-body)",
                        background: "var(--parchment)",
                        border: "1.5px solid var(--fog)",
                        borderRadius: "var(--radius-sm)",
                        color: "var(--soil)",
                        resize: "vertical",
                        outline: "none",
                      }}
                      onFocus={(e) => (e.target.style.borderColor = "var(--meadow)")}
                      onBlur={(e) => (e.target.style.borderColor = "var(--fog)")}
                    />
                  </div>
                </div>
              )}
            </section>

            {/* API error */}
            {apiError && (
              <div
                style={{
                  padding: "12px 16px",
                  background: "#fff0f0",
                  border: "1px solid #f5c6c6",
                  borderRadius: "var(--radius-sm)",
                  fontSize: 13,
                  color: "#8b2020",
                }}
              >
                ⚠ {apiError}
              </div>
            )}

            {/* Submit */}
            <button
              type="button"
              onClick={handleSubmit}
              disabled={jobs.length === 0}
              style={{
                width: "100%",
                padding: "16px",
                background: "var(--meadow)",
                color: "#fff",
                border: "none",
                borderRadius: "var(--radius-md)",
                fontSize: 16,
                fontWeight: 600,
                fontFamily: "var(--font-body)",
                cursor: jobs.length === 0 ? "not-allowed" : "pointer",
                opacity: jobs.length === 0 ? 0.6 : 1,
                transition: "all 0.2s",
                letterSpacing: "0.01em",
              }}
              onMouseEnter={(e) => {
                if (jobs.length > 0) {
                  (e.currentTarget as HTMLButtonElement).style.background = "var(--grass)";
                  (e.currentTarget as HTMLButtonElement).style.transform = "translateY(-1px)";
                  (e.currentTarget as HTMLButtonElement).style.boxShadow = "0 6px 20px rgba(61,107,53,0.3)";
                }
              }}
              onMouseLeave={(e) => {
                (e.currentTarget as HTMLButtonElement).style.background = "var(--meadow)";
                (e.currentTarget as HTMLButtonElement).style.transform = "none";
                (e.currentTarget as HTMLButtonElement).style.boxShadow = "none";
              }}
            >
              Get my instant quote →
            </button>
          </div>
        )}

        {/* ── LOADING ─────────────────────────────────────────────────── */}
        {stage === "loading" && <QuoteLoading />}

        {/* ── RESULT ──────────────────────────────────────────────────── */}
        {stage === "result" && quote && (
          <QuoteCard
            quote={quote}
            address={form.addressDisplay}
            onReset={handleReset}
          />
        )}
      </main>

      {/* Footer */}
      <footer
        style={{
          textAlign: "center",
          padding: "40px 16px 0",
          fontSize: 12,
          color: "var(--clay)",
          opacity: 0.7,
        }}
      >
        Quotes are estimates only. Final price confirmed on-site.
      </footer>
    </div>
  );
}

// ─── Helpers ──────────────────────────────────────────────────────────────────

function SectionLabel({
  number, title, subtitle,
}: {
  number: number;
  title: string;
  subtitle?: string;
}) {
  return (
    <div style={{ marginBottom: 12 }}>
      <div style={{ display: "flex", alignItems: "center", gap: 10 }}>
        <span
          style={{
            width: 24,
            height: 24,
            borderRadius: "50%",
            background: "var(--meadow)",
            color: "#fff",
            fontSize: 12,
            fontWeight: 700,
            display: "flex",
            alignItems: "center",
            justifyContent: "center",
            flexShrink: 0,
          }}
        >
          {number}
        </span>
        <h2 style={{ fontFamily: "var(--font-display)", fontSize: 18, color: "var(--bark)" }}>
          {title}
        </h2>
      </div>
      {subtitle && (
        <p style={{ fontSize: 11, color: "var(--clay)", marginTop: 4, marginLeft: 34 }}>
          {subtitle}
        </p>
      )}
    </div>
  );
}

function extractSuburb(address: string): string {
  // Very rough fallback: take the second-to-last comma-separated segment
  const parts = address.split(",").map((p) => p.trim());
  if (parts.length >= 2) return parts[parts.length - 2].replace(/\s+QLD.*/, "").trim();
  return "Unknown";
}
