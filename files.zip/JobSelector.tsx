"use client";
// src/components/JobSelector.tsx
// Checkbox cards for selecting landscaping services.

import { Job } from "@/lib/api";

const JOB_ICONS: Record<string, string> = {
  lawn_mowing:              "🌿",
  hedge_trimming:           "✂️",
  gutter_cleaning:          "🍂",
  pressure_washing_driveway:"💧",
  roof_cleaning:            "🏠",
  garden_tidy:              "🌱",
};

interface Props {
  jobs: Job[];
  selected: string[];
  onChange: (ids: string[]) => void;
  error?: string;
  disabled?: boolean;
}

export default function JobSelector({ jobs, selected, onChange, error, disabled }: Props) {
  const toggle = (id: string) => {
    if (disabled) return;
    onChange(
      selected.includes(id)
        ? selected.filter((s) => s !== id)
        : [...selected, id]
    );
  };

  return (
    <div>
      <div
        style={{
          display: "grid",
          gridTemplateColumns: "repeat(auto-fill, minmax(175px, 1fr))",
          gap: 10,
        }}
      >
        {jobs.map((job) => {
          const active = selected.includes(job.id);
          return (
            <button
              key={job.id}
              type="button"
              onClick={() => toggle(job.id)}
              disabled={disabled}
              style={{
                display: "flex",
                flexDirection: "column",
                alignItems: "flex-start",
                gap: 6,
                padding: "14px 14px 12px",
                background: active ? "var(--meadow)" : "var(--parchment)",
                border: `1.5px solid ${active ? "var(--meadow)" : "var(--fog)"}`,
                borderRadius: "var(--radius-md)",
                cursor: disabled ? "not-allowed" : "pointer",
                opacity: disabled ? 0.6 : 1,
                transition: "all 0.18s cubic-bezier(0.22,1,0.36,1)",
                textAlign: "left",
                boxShadow: active ? "0 4px 16px rgba(61,107,53,0.25)" : "var(--shadow-card)",
                transform: active ? "translateY(-1px)" : "none",
              }}
              onMouseEnter={(e) => {
                if (!active && !disabled) {
                  (e.currentTarget as HTMLButtonElement).style.borderColor = "var(--sage)";
                  (e.currentTarget as HTMLButtonElement).style.background = "#f5f0e8";
                }
              }}
              onMouseLeave={(e) => {
                if (!active && !disabled) {
                  (e.currentTarget as HTMLButtonElement).style.borderColor = "var(--fog)";
                  (e.currentTarget as HTMLButtonElement).style.background = "var(--parchment)";
                }
              }}
            >
              <span style={{ fontSize: 22, lineHeight: 1 }}>
                {JOB_ICONS[job.id] || "🔧"}
              </span>
              <span
                style={{
                  fontSize: 13,
                  fontWeight: 600,
                  fontFamily: "var(--font-body)",
                  color: active ? "#fff" : "var(--bark)",
                  lineHeight: 1.3,
                }}
              >
                {job.name}
              </span>
              <span
                style={{
                  fontSize: 11,
                  color: active ? "rgba(255,255,255,0.8)" : "var(--clay)",
                  fontFamily: "var(--font-body)",
                }}
              >
                from ${job.min_charge}
              </span>

              {/* Tick */}
              {active && (
                <span
                  style={{
                    position: "absolute" as const,
                    top: 8,
                    right: 10,
                    width: 18,
                    height: 18,
                    background: "rgba(255,255,255,0.25)",
                    borderRadius: "50%",
                    display: "flex",
                    alignItems: "center",
                    justifyContent: "center",
                    fontSize: 10,
                    color: "#fff",
                  }}
                >
                  ✓
                </span>
              )}
            </button>
          );
        })}
      </div>

      {error && (
        <p style={{ marginTop: 8, fontSize: 13, color: "#c0392b" }}>{error}</p>
      )}

      {selected.length > 1 && (
        <p
          style={{
            marginTop: 10,
            fontSize: 12,
            color: "var(--meadow)",
            fontWeight: 500,
          }}
        >
          ✓ Multi-service discount applied automatically
        </p>
      )}
    </div>
  );
}
