"use client";
// src/components/PropertyInputs.tsx
// Manual property size inputs for Step 3.
// Step 4 will replace these with auto-detected values from the Maps Vision agent.
// When Step 4 is live, these will become read-only fields showing the detected values.

interface Sizes {
  lawn_sqm: number;
  driveway_sqm: number;
  roof_sqm: number;
  garden_sqm: number;
}

interface Props {
  values: Sizes;
  onChange: (key: keyof Sizes, value: number) => void;
  disabled?: boolean;
  autoDetected?: boolean; // Step 4: true when values came from Maps Vision
}

const FIELDS: { key: keyof Sizes; label: string; hint: string; placeholder: string }[] = [
  { key: "lawn_sqm",      label: "Lawn area",      hint: "Grass/turf area",       placeholder: "e.g. 250" },
  { key: "driveway_sqm",  label: "Driveway area",   hint: "Sealed surfaces",       placeholder: "e.g. 40"  },
  { key: "roof_sqm",      label: "Roof area",       hint: "Footprint of roof",     placeholder: "e.g. 160" },
  { key: "garden_sqm",    label: "Garden beds",     hint: "Planted / mulched areas", placeholder: "e.g. 30" },
];

// Quick-select size presets for people who don't know their m²
const PRESETS = [
  { label: "Small block", values: { lawn_sqm: 120, driveway_sqm: 25, roof_sqm: 110, garden_sqm: 20 } },
  { label: "Average house", values: { lawn_sqm: 250, driveway_sqm: 45, roof_sqm: 155, garden_sqm: 35 } },
  { label: "Large block", values: { lawn_sqm: 450, driveway_sqm: 70, roof_sqm: 200, garden_sqm: 60 } },
];

export default function PropertyInputs({ values, onChange, disabled, autoDetected }: Props) {
  const applyPreset = (preset: typeof PRESETS[0]) => {
    Object.entries(preset.values).forEach(([k, v]) =>
      onChange(k as keyof Sizes, v)
    );
  };

  return (
    <div>
      {/* Quick presets */}
      {!autoDetected && (
        <div style={{ marginBottom: 14 }}>
          <p style={{ fontSize: 12, color: "var(--clay)", marginBottom: 8 }}>
            Not sure of your sizes? Pick a preset:
          </p>
          <div style={{ display: "flex", gap: 8, flexWrap: "wrap" as const }}>
            {PRESETS.map((p) => (
              <button
                key={p.label}
                type="button"
                onClick={() => applyPreset(p)}
                disabled={disabled}
                style={{
                  padding: "6px 14px",
                  fontSize: 12,
                  fontFamily: "var(--font-body)",
                  fontWeight: 500,
                  background: "var(--parchment)",
                  border: "1.5px solid var(--fog)",
                  borderRadius: "var(--radius-sm)",
                  color: "var(--bark)",
                  cursor: disabled ? "not-allowed" : "pointer",
                  transition: "all 0.15s",
                }}
                onMouseEnter={(e) => {
                  if (!disabled) {
                    (e.currentTarget as HTMLButtonElement).style.borderColor = "var(--straw)";
                    (e.currentTarget as HTMLButtonElement).style.background = "#fdf8f0";
                  }
                }}
                onMouseLeave={(e) => {
                  if (!disabled) {
                    (e.currentTarget as HTMLButtonElement).style.borderColor = "var(--fog)";
                    (e.currentTarget as HTMLButtonElement).style.background = "var(--parchment)";
                  }
                }}
              >
                {p.label}
              </button>
            ))}
          </div>
        </div>
      )}

      {autoDetected && (
        <div
          style={{
            display: "flex",
            alignItems: "center",
            gap: 8,
            marginBottom: 12,
            padding: "8px 12px",
            background: "rgba(61,107,53,0.08)",
            borderRadius: "var(--radius-sm)",
            border: "1px solid rgba(61,107,53,0.2)",
          }}
        >
          <span style={{ fontSize: 14 }}>🛰</span>
          <span style={{ fontSize: 12, color: "var(--meadow)", fontWeight: 500 }}>
            Sizes automatically detected from satellite imagery
          </span>
        </div>
      )}

      {/* Input grid */}
      <div
        style={{
          display: "grid",
          gridTemplateColumns: "repeat(2, 1fr)",
          gap: 10,
        }}
      >
        {FIELDS.map(({ key, label, hint, placeholder }) => (
          <label key={key} style={{ display: "flex", flexDirection: "column", gap: 4 }}>
            <span style={{ fontSize: 12, fontWeight: 500, color: "var(--bark)" }}>
              {label}
            </span>
            <span style={{ fontSize: 11, color: "var(--clay)" }}>{hint}</span>
            <div style={{ position: "relative" }}>
              <input
                type="number"
                min={0}
                value={values[key] || ""}
                onChange={(e) => onChange(key, parseFloat(e.target.value) || 0)}
                placeholder={placeholder}
                disabled={disabled || autoDetected}
                style={{
                  width: "100%",
                  padding: "10px 36px 10px 12px",
                  fontSize: 15,
                  fontFamily: "var(--font-body)",
                  background: autoDetected ? "rgba(61,107,53,0.04)" : "var(--parchment)",
                  border: "1.5px solid var(--fog)",
                  borderRadius: "var(--radius-sm)",
                  color: "var(--soil)",
                  outline: "none",
                }}
                onFocus={(e) => {
                  e.target.style.borderColor = "var(--meadow)";
                }}
                onBlur={(e) => {
                  e.target.style.borderColor = "var(--fog)";
                }}
              />
              <span
                style={{
                  position: "absolute",
                  right: 10,
                  top: "50%",
                  transform: "translateY(-50%)",
                  fontSize: 11,
                  color: "var(--clay)",
                  pointerEvents: "none",
                  fontWeight: 500,
                }}
              >
                m²
              </span>
            </div>
          </label>
        ))}
      </div>
    </div>
  );
}
