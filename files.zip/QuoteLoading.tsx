"use client";
// src/components/QuoteLoading.tsx
// Skeleton shown while the AI pipeline is running (~5–8 seconds).

import { useEffect, useState } from "react";

const STEPS = [
  { icon: "📍", text: "Locating your property..." },
  { icon: "🗺", text: "Reading suburb profile..." },
  { icon: "🧮", text: "Calculating job estimates..." },
  { icon: "🤖", text: "AI finalising your quote..." },
];

export default function QuoteLoading() {
  const [step, setStep] = useState(0);

  useEffect(() => {
    const timings = [600, 1800, 3200]; // ms to advance steps
    const timers = timings.map((t, i) =>
      setTimeout(() => setStep(i + 1), t)
    );
    return () => timers.forEach(clearTimeout);
  }, []);

  return (
    <div
      className="animate-fade-in"
      style={{
        background: "var(--parchment)",
        borderRadius: "var(--radius-lg)",
        padding: "36px 28px",
        boxShadow: "var(--shadow-float)",
        border: "1px solid var(--fog)",
      }}
    >
      <p
        style={{
          fontFamily: "var(--font-display)",
          fontSize: 22,
          color: "var(--bark)",
          marginBottom: 28,
          textAlign: "center",
        }}
      >
        Building your quote...
      </p>

      {/* Progress steps */}
      <div style={{ display: "flex", flexDirection: "column", gap: 14, marginBottom: 32 }}>
        {STEPS.map((s, i) => {
          const done = i < step;
          const active = i === step;
          return (
            <div
              key={i}
              style={{
                display: "flex",
                alignItems: "center",
                gap: 12,
                opacity: done || active ? 1 : 0.3,
                transition: "opacity 0.4s",
              }}
            >
              <div
                style={{
                  width: 32,
                  height: 32,
                  borderRadius: "50%",
                  background: done ? "var(--meadow)" : active ? "var(--fog)" : "var(--fog)",
                  display: "flex",
                  alignItems: "center",
                  justifyContent: "center",
                  fontSize: 14,
                  flexShrink: 0,
                  transition: "background 0.3s",
                  border: active ? "2px solid var(--sage)" : "2px solid transparent",
                }}
              >
                {done ? (
                  <span style={{ color: "#fff", fontSize: 13 }}>✓</span>
                ) : (
                  <span>{s.icon}</span>
                )}
              </div>
              <span
                style={{
                  fontSize: 14,
                  color: done ? "var(--meadow)" : active ? "var(--bark)" : "var(--clay)",
                  fontWeight: active ? 500 : 400,
                  transition: "color 0.3s",
                }}
              >
                {s.text}
              </span>
              {active && (
                <div
                  style={{
                    width: 14,
                    height: 14,
                    borderRadius: "50%",
                    border: "2px solid var(--sage)",
                    borderTopColor: "var(--meadow)",
                    animation: "spin 0.7s linear infinite",
                    flexShrink: 0,
                  }}
                />
              )}
            </div>
          );
        })}
      </div>

      {/* Skeleton price preview */}
      <div
        style={{
          background: "var(--mist)",
          borderRadius: "var(--radius-md)",
          padding: "20px",
          border: "1px solid var(--fog)",
        }}
      >
        {[80, 55, 65, 40].map((w, i) => (
          <div
            key={i}
            style={{
              height: i === 0 ? 32 : 14,
              width: `${w}%`,
              background: "linear-gradient(90deg, var(--fog) 25%, #e8e2d0 50%, var(--fog) 75%)",
              backgroundSize: "400px 100%",
              borderRadius: 6,
              marginBottom: i === 0 ? 14 : 10,
              animation: "shimmer 1.6s infinite",
            }}
          />
        ))}
      </div>
    </div>
  );
}
