// src/lib/api.ts
// Typed client for the FastAPI backend.
// All API calls go through here — one place to update if the backend changes.

const API_BASE = process.env.NEXT_PUBLIC_API_URL || "http://localhost:8000";

// ─── Types ────────────────────────────────────────────────────────────────────

export interface Job {
  id: string;
  name: string;
  description: string;
  unit: string;
  min_charge: number;
}

export interface QuoteRequest {
  address: string;
  suburb: string;
  state: string;
  job_ids: string[];
  lawn_sqm: number;
  driveway_sqm: number;
  roof_sqm: number;
  garden_sqm: number;
  condition_score: number;
  condition_context: string;
  travel_zone: "A" | "B" | "C";
  terrain: "flat" | "sloped" | "unknown";
  access_notes?: string;
}

export interface LineItem {
  job_id: string;
  job_name: string;
  min: number;
  max: number;
  notes: string;
}

export interface QuoteResponse {
  quote_id?: string;
  total_min: number;
  total_max: number;
  currency: string;
  confidence: "high" | "medium" | "low";
  multi_job_discount_applied: boolean;
  line_items: LineItem[];
  summary: string;
  caveats: string;
}

// ─── API calls ────────────────────────────────────────────────────────────────

export async function fetchJobs(): Promise<Job[]> {
  const res = await fetch(`${API_BASE}/jobs`);
  if (!res.ok) throw new Error("Failed to load job types");
  const data = await res.json();
  return data.jobs;
}

export async function submitQuote(request: QuoteRequest): Promise<QuoteResponse> {
  const res = await fetch(`${API_BASE}/quote`, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify(request),
  });
  if (!res.ok) {
    const err = await res.json().catch(() => ({}));
    throw new Error(err.detail || `Quote request failed (${res.status})`);
  }
  return res.json();
}
