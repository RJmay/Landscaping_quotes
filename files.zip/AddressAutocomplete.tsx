"use client";
// src/components/AddressAutocomplete.tsx
// Google Places autocomplete for Australian addresses.
// Falls back to a plain text input if the Maps API key isn't configured.

import { useEffect, useRef, useState } from "react";

interface ParsedAddress {
  full: string;       // "42 Eucalyptus Drive, Calamvale QLD 4116"
  suburb: string;     // "Calamvale"
  state: string;      // "QLD"
  postcode: string;   // "4116"
}

interface Props {
  value: string;
  onChange: (display: string, parsed: ParsedAddress | null) => void;
  error?: string;
  disabled?: boolean;
}

declare global {
  interface Window {
    google?: {
      maps: {
        places: {
          Autocomplete: new (
            input: HTMLInputElement,
            options: object
          ) => {
            addListener: (event: string, handler: () => void) => void;
            getPlace: () => {
              formatted_address?: string;
              address_components?: Array<{
                long_name: string;
                short_name: string;
                types: string[];
              }>;
            };
          };
        };
      };
    };
  }
}

export default function AddressAutocomplete({ value, onChange, error, disabled }: Props) {
  const inputRef = useRef<HTMLInputElement>(null);
  const autocompleteRef = useRef<ReturnType<typeof window.google.maps.places.Autocomplete> | null>(null);
  const [mapsReady, setMapsReady] = useState(false);

  // Check if Google Maps is loaded
  useEffect(() => {
    const check = () => {
      if (window.google?.maps?.places) {
        setMapsReady(true);
      } else {
        setTimeout(check, 300);
      }
    };
    check();
  }, []);

  // Attach autocomplete once Maps is ready
  useEffect(() => {
    if (!mapsReady || !inputRef.current || autocompleteRef.current) return;

    autocompleteRef.current = new window.google.maps.places.Autocomplete(
      inputRef.current,
      {
        componentRestrictions: { country: "au" },
        types: ["address"],
        fields: ["formatted_address", "address_components"],
      }
    );

    autocompleteRef.current.addListener("place_changed", () => {
      const place = autocompleteRef.current!.getPlace();
      if (!place?.address_components) return;

      const get = (type: string, short = false) => {
        const c = place.address_components!.find((c) => c.types.includes(type));
        return c ? (short ? c.short_name : c.long_name) : "";
      };

      const parsed: ParsedAddress = {
        full: place.formatted_address || "",
        suburb: get("locality") || get("sublocality"),
        state: get("administrative_area_level_1", true),
        postcode: get("postal_code"),
      };

      onChange(place.formatted_address || "", parsed);
    });
  }, [mapsReady, onChange]);

  return (
    <div style={{ position: "relative" }}>
      <input
        ref={inputRef}
        type="text"
        value={value}
        onChange={(e) => onChange(e.target.value, null)}
        placeholder={
          mapsReady
            ? "Start typing your address..."
            : "Enter your address"
        }
        disabled={disabled}
        autoComplete="off"
        style={{
          width: "100%",
          padding: "14px 16px 14px 44px",
          fontSize: "16px",
          fontFamily: "var(--font-body)",
          background: "var(--parchment)",
          border: `1.5px solid ${error ? "#c0392b" : "var(--fog)"}`,
          borderRadius: "var(--radius-md)",
          color: "var(--soil)",
          outline: "none",
          transition: "border-color 0.2s, box-shadow 0.2s",
          boxShadow: error ? "0 0 0 3px rgba(192,57,43,0.1)" : "none",
        }}
        onFocus={(e) => {
          if (!error) {
            e.target.style.borderColor = "var(--meadow)";
            e.target.style.boxShadow = "0 0 0 3px rgba(61,107,53,0.12)";
          }
        }}
        onBlur={(e) => {
          if (!error) {
            e.target.style.borderColor = "var(--fog)";
            e.target.style.boxShadow = "none";
          }
        }}
      />

      {/* Pin icon */}
      <svg
        width="18" height="18"
        viewBox="0 0 24 24" fill="none"
        style={{ position: "absolute", left: 14, top: "50%", transform: "translateY(-50%)", pointerEvents: "none" }}
      >
        <path
          d="M12 2C8.13 2 5 5.13 5 9c0 5.25 7 13 7 13s7-7.75 7-13c0-3.87-3.13-7-7-7zm0 9.5c-1.38 0-2.5-1.12-2.5-2.5s1.12-2.5 2.5-2.5 2.5 1.12 2.5 2.5-1.12 2.5-2.5 2.5z"
          fill="var(--clay)" opacity="0.7"
        />
      </svg>

      {error && (
        <p style={{ marginTop: 6, fontSize: 13, color: "#c0392b" }}>{error}</p>
      )}

      {!mapsReady && (
        <p style={{ marginTop: 4, fontSize: 12, color: "var(--clay)" }}>
          Tip: add a Google Maps API key in .env.local for address autocomplete
        </p>
      )}
    </div>
  );
}
